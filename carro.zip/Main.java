

public class Main {

	public static void main(String[] args) {
		
		//construtor objeto vazio
		Carro carro1 = new Carro();
		
		carro1.setMarca("Gol");
		carro1.setCor("Amarelo");
		carro1.setPortas(4);
		
		//...............................................
		

		
		
		//criando objeto com parametro
		Carro carro2 = new Carro(1, "Uno", "azul",2);

		
		
		
		//set para trocar o nome
		carro2.setCor("Preto");
	//..........................................................
	
System.out.println("A marca do carro é "+carro1.getMarca() + " e é  "+carro1.getCor() +" com " + carro1.getPortas() +" portas.");
System.out.println("A marca do carro é "+carro2.getMarca() + " e é  "+carro2.getCor() +" com " + carro2.getPortas() +" portas.");


	}

}
